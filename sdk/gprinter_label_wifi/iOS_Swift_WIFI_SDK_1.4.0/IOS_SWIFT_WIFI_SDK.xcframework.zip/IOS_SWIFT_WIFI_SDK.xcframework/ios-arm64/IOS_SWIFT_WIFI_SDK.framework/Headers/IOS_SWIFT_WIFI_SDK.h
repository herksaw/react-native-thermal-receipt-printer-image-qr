//
//  IOS_SWIFT_WIFI_SDK.h
//  IOS_SWIFT_WIFI_SDK
//
//  Created on 2021/12/2.
//

#import <Foundation/Foundation.h>

//! Project version number for IOS_SWIFT_WIFI_SDK.
FOUNDATION_EXPORT double IOS_SWIFT_WIFI_SDKVersionNumber;

//! Project version string for IOS_SWIFT_WIFI_SDK.
FOUNDATION_EXPORT const unsigned char IOS_SWIFT_WIFI_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IOS_SWIFT_WIFI_SDK/PublicHeader.h>


